# Thiranex EDA Project

## Files
- `EDA_Project_Thiranex.ipynb` - complete Jupyter Notebook
- `eda_project.py` - Python script version
- `diabetes_eda_dataset.csv` - dataset used
- `EDA_Project_Report.pdf` - ready-to-submit report
- `plots/` - generated visualizations

## How to run
1. Open the `.ipynb` file in Jupyter Notebook, JupyterLab, Google Colab, or VS Code.
2. Run all cells from top to bottom.
3. If submitting the notebook, keep the outputs visible after running.
4. The project uses pandas, numpy, matplotlib, seaborn and scikit-learn.

## Dataset note
The dataset is the public Diabetes dataset distributed through scikit-learn. It contains 442 samples, 10 baseline features, and a target measure of disease progression.

## Main EDA findings
- Rows: 442
- Columns: 11
- Missing values: 0
- Duplicate rows: 0
- Strongest absolute feature-target correlation: bmi (0.586)
