# Exploratory Data Analysis (EDA) Project
# Thiranex submission project
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

df = pd.read_csv("diabetes_eda_dataset.csv")

print("Shape:", df.shape)
print("\nColumns:\n", df.columns.tolist())
print("\nData types:\n", df.dtypes)
print("\nMissing values:\n", df.isnull().sum())
print("\nDuplicate rows:", df.duplicated().sum())
print("\nStatistical summary:\n", df.describe())

# Target distribution
plt.figure(figsize=(8,5))
sns.histplot(df["target"], bins=20, kde=True)
plt.title("Distribution of Target")
plt.xlabel("Target")
plt.show()

# Correlation matrix
plt.figure(figsize=(10,8))
sns.heatmap(df.corr(numeric_only=True), annot=True, cmap="coolwarm", fmt=".2f")
plt.title("Correlation Matrix")
plt.show()

# Feature-target correlations
corr = df.corr(numeric_only=True)["target"].drop("target").sort_values()
print("\nCorrelation with target:\n", corr)

plt.figure(figsize=(9,5))
corr.plot(kind="bar")
plt.title("Feature Correlation with Target")
plt.ylabel("Pearson Correlation")
plt.xticks(rotation=45)
plt.show()

# Strongest relationship
strongest = corr.abs().idxmax()
print("\nFeature with strongest absolute correlation:", strongest)

plt.figure(figsize=(7,5))
sns.regplot(data=df, x=strongest, y="target", scatter_kws={"alpha":0.6})
plt.title(f"{strongest} vs Target")
plt.show()

# Outlier inspection
plt.figure(figsize=(11,6))
sns.boxplot(data=df.drop(columns="target"))
plt.xticks(rotation=45)
plt.title("Feature Distributions and Potential Outliers")
plt.show()
